"""
Synthetic leakage test dataset generator
========================================
Creates a reproducible, physics-inspired dataset for prototyping leakage
test-time reduction methods: early termination, IDDQ vector reduction,
hot-from-room prediction, adaptive test and group pin-leakage testing.

All data is synthetic. No real product, fab or tester data is used.

Outputs (written next to this script, in ./data):
  die_data.csv              one row per die: ids, wafer coordinates, process
                            monitors, 20 room + 20 hot IDDQ readings, standby
                            mode currents, pass/fail vs limits, ground truth
  settling_transients.csv   supply-current settling waveforms (0-8 ms) for a
                            subset of dice and vectors, plus true final value
  pin_leakage.csv           per-pin input leakage (32 pins per die)
  vector_info.csv           per-vector defect activation probability (truth)

Usage:  python generate_synthetic_leakage_data.py [--seed 42] [--radius 11]
"""
import argparse
import os
import numpy as np
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument("--seed", type=int, default=42)
p.add_argument("--lots", type=int, default=6)
p.add_argument("--wafers", type=int, default=5, help="wafers per lot")
p.add_argument("--radius", type=int, default=11, help="wafer radius in die units")
p.add_argument("--n_transient_dice", type=int, default=1500)
args = p.parse_args()

rng = np.random.default_rng(args.seed)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------- constants
N_VEC = 20
N_PINS = 32
N_SITES = 4
VT_25 = 0.025693          # thermal voltage at 25 C (V)
N_SLOPE = 1.5             # subthreshold slope factor
I_NOM_ROOM = 8.0          # uA, nominal background IDDQ at 25 C, dVth = 0
HOT_RATIO_NOM = 25.0      # nominal 125 C / 25 C leakage ratio
MEAS_NOISE = 0.30         # uA, room IDDQ measurement noise (1 sigma)
LIMIT_ROOM = 50.0         # uA, room IDDQ limit (any vector)
LIMIT_HOT = 1500.0        # uA, hot IDDQ limit (any vector)
PIN_LIMIT = 100.0         # nA, per-pin leakage limit
P_BRIDGE = 0.012          # fraction of dice with a bridging-type defect
P_TEMP = 0.003            # fraction with a temperature-activated defect
P_PIN = 0.005             # fraction with an ESD-damaged (leaky) pin

# Per-vector defect activation probability: some vectors exercise many more
# potential bridge sites than others (this is what makes vector selection matter)
vec_p_activate = np.clip(rng.beta(1.6, 3.0, N_VEC), 0.03, 0.8)
vec_scale = rng.normal(1.0, 0.05, N_VEC)        # vector-dependent background factor

# ----------------------------------------------------------------- die grid
xs, ys = np.meshgrid(np.arange(-args.radius, args.radius + 1), np.arange(-args.radius, args.radius + 1))
mask = xs ** 2 + ys ** 2 <= args.radius ** 2
die_x, die_y = xs[mask], ys[mask]
r_norm = np.sqrt(die_x ** 2 + die_y ** 2) / args.radius

rows = []
die_counter = 0
for lot in range(args.lots):
    lot_id = f"LOT{lot + 1:02d}"
    lot_off = rng.normal(0, 8)                       # mV, lot-level Vth offset
    for w in range(args.wafers):
        wafer_id = f"{lot_id}_W{w + 1:02d}"
        waf_off = rng.normal(0, 4)                   # mV
        radial = rng.normal(6, 3)                    # mV at edge (bowl/dome)
        tilt_ang = rng.uniform(0, 2 * np.pi)
        tilt = rng.normal(0, 3)                      # mV across wafer
        dvth = (lot_off + waf_off + radial * r_norm ** 2
                + tilt * (np.cos(tilt_ang) * die_x + np.sin(tilt_ang) * die_y) / args.radius
                + rng.normal(0, 5, die_x.size))      # die-level random component
        pcm_vth = 0.350 + (lot_off + waf_off) / 1000 + rng.normal(0, 0.002)  # V, wafer PCM
        for i in range(die_x.size):
            rows.append(dict(die_id=f"D{die_counter:06d}", lot_id=lot_id, wafer_id=wafer_id,
                             die_x=int(die_x[i]), die_y=int(die_y[i]), r_norm=round(r_norm[i], 4),
                             dvth_true_mV=dvth[i], pcm_vth_V=pcm_vth))
            die_counter += 1

df = pd.DataFrame(rows)
n = len(df)
df["site"] = np.arange(n) % N_SITES
dv = df["dvth_true_mV"].to_numpy() / 1000.0

# ----------------------------------------------------------------- process monitors
# Ring oscillator: lower Vth -> faster; small measurement noise
df["rosc_MHz"] = 500.0 * (1 - 2.0 * dv) + rng.normal(0, 1.5, n)
df["rosc_hvt_MHz"] = 310.0 * (1 - 2.6 * dv) + rng.normal(0, 1.2, n)

# ----------------------------------------------------------------- defects (ground truth)
u = rng.random(n)
defect_type = np.full(n, "none", dtype=object)
defect_type[u < P_BRIDGE] = "bridge"
defect_type[(u >= P_BRIDGE) & (u < P_BRIDGE + P_TEMP)] = "temp_activated"
defect_type[(u >= P_BRIDGE + P_TEMP) & (u < P_BRIDGE + P_TEMP + P_PIN)] = "pin_esd"
df["defect_type"] = defect_type
df["is_defective"] = (defect_type != "none").astype(int)

# ----------------------------------------------------------------- background leakage
i_bg_room = I_NOM_ROOM * np.exp(-dv / (N_SLOPE * VT_25)) * rng.lognormal(0, 0.08, n)
hot_ratio = HOT_RATIO_NOM * np.exp(4.0 * dv + rng.normal(0, 0.05, n))
i_bg_hot = i_bg_room * hot_ratio

# defect current per die and activation per vector
def_mag = rng.lognormal(np.log(15.0), 0.8, n)            # uA at room for bridges
act = rng.random((n, N_VEC)) < vec_p_activate[None, :]
is_bridge = defect_type == "bridge"
is_temp = defect_type == "temp_activated"
# guarantee at least one activated vector for each bridge
no_act = is_bridge & ~act.any(axis=1)
act[no_act, rng.integers(0, N_VEC, no_act.sum())] = True
def_room = np.zeros((n, N_VEC))
def_hot = np.zeros((n, N_VEC))
def_room[is_bridge] = act[is_bridge] * def_mag[is_bridge, None]
def_hot[is_bridge] = def_room[is_bridge] * rng.uniform(1.5, 3.0, (is_bridge.sum(), 1))
# temperature-activated: weak at room (10%), strong at hot
def_room[is_temp] = act[is_temp] * def_mag[is_temp, None] * 0.10
def_hot[is_temp] = act[is_temp] * def_mag[is_temp, None] * rng.uniform(15, 40, (is_temp.sum(), 1))

state_noise = rng.normal(0, 0.02, (n, N_VEC))           # per-die state-dependent variation
true_room = i_bg_room[:, None] * vec_scale[None, :] * (1 + state_noise) + def_room
true_hot = i_bg_hot[:, None] * vec_scale[None, :] * (1 + state_noise) + def_hot
meas_room = true_room + rng.normal(0, MEAS_NOISE, (n, N_VEC))
meas_hot = true_hot + rng.normal(0, MEAS_NOISE * 5, (n, N_VEC))

for v in range(N_VEC):
    df[f"iddq_room_v{v + 1:02d}_uA"] = np.round(meas_room[:, v], 3)
for v in range(N_VEC):
    df[f"iddq_hot_v{v + 1:02d}_uA"] = np.round(meas_hot[:, v], 2)

# ----------------------------------------------------------------- standby / power-mode currents (room)
df["isb_sleep_uA"] = np.round(i_bg_room * 0.42 * rng.lognormal(0, 0.04, n) + rng.normal(0, 0.1, n), 3)
df["isb_retention_uA"] = np.round(i_bg_room * 0.11 * rng.lognormal(0, 0.05, n) + rng.normal(0, 0.05, n), 3)
df["isb_off_uA"] = np.round(i_bg_room * 0.015 * rng.lognormal(0, 0.08, n) + rng.normal(0, 0.02, n), 4)

# ----------------------------------------------------------------- limit-based results
df["room_iddq_max_uA"] = np.round(meas_room.max(axis=1), 3)
df["hot_iddq_max_uA"] = np.round(meas_hot.max(axis=1), 2)
df["room_iddq_pass"] = (meas_room.max(axis=1) < LIMIT_ROOM).astype(int)
df["hot_iddq_pass"] = (meas_hot.max(axis=1) < LIMIT_HOT).astype(int)

# ----------------------------------------------------------------- pin leakage
pin_base = rng.lognormal(np.log(2.0), 0.5, (n, N_PINS)) * np.exp(-dv / (N_SLOPE * VT_25) * 0.3)[:, None]
is_pin = defect_type == "pin_esd"
bad_pin = rng.integers(0, N_PINS, n)
pin_vals = pin_base.copy()
idx = np.where(is_pin)[0]
pin_vals[idx, bad_pin[idx]] += rng.lognormal(np.log(250), 1.0, idx.size)
pin_vals += np.abs(rng.normal(0, 0.2, (n, N_PINS)))
df["pin_leak_max_nA"] = np.round(pin_vals.max(axis=1), 3)
df["pin_leak_pass"] = (pin_vals.max(axis=1) < PIN_LIMIT).astype(int)
df["bad_pin_true"] = np.where(is_pin, bad_pin, -1)

pin_df = pd.DataFrame({
    "die_id": np.repeat(df["die_id"].to_numpy(), N_PINS),
    "pin": np.tile(np.arange(N_PINS), n),
    "leak_nA": np.round(pin_vals.ravel(), 3),
})

# ----------------------------------------------------------------- settling transients
t = np.round(np.arange(0, 8.0001, 0.1), 1)                 # ms
site_tau = np.array([0.70, 0.80, 0.90, 1.00])              # ms, fast board/die time constant per site
tr_dice = rng.choice(n, size=min(args.n_transient_dice, n), replace=False)
tr_vectors = [1, 7, 14]
tr_rows = []
for d in tr_dice:
    s = df.at[d, "site"]
    for v in tr_vectors:
        i_final = true_room[d, v - 1]
        a1 = rng.lognormal(np.log(120), 0.3)
        tau1 = site_tau[s] * rng.lognormal(0, 0.10)
        a2 = rng.lognormal(np.log(10), 0.4)                # slow tail (regulator / package)
        tau2 = 2.5 * rng.lognormal(0, 0.15)
        wave = i_final + a1 * np.exp(-t / tau1) + a2 * np.exp(-t / tau2) + rng.normal(0, 0.4, t.size)
        rec = {"die_id": df.at[d, "die_id"], "site": s, "vector": v,
               "i_final_true_uA": round(i_final, 3), "tau1_ms": round(tau1, 3), "tau2_ms": round(tau2, 3)}
        for tt, val in zip(t, wave):
            rec[f"t{tt:.1f}ms"] = round(val, 3)
        tr_rows.append(rec)
tr_df = pd.DataFrame(tr_rows)

vec_df = pd.DataFrame({"vector": np.arange(1, N_VEC + 1),
                       "defect_activation_prob_true": np.round(vec_p_activate, 4),
                       "background_scale_true": np.round(vec_scale, 4)})

# ----------------------------------------------------------------- write
df["dvth_true_mV"] = df["dvth_true_mV"].round(3)
df["pcm_vth_V"] = df["pcm_vth_V"].round(5)
df["rosc_MHz"] = df["rosc_MHz"].round(2)
df["rosc_hvt_MHz"] = df["rosc_hvt_MHz"].round(2)
df.to_csv(os.path.join(OUT, "die_data.csv"), index=False)
tr_df.to_csv(os.path.join(OUT, "settling_transients.csv"), index=False)
pin_df.to_csv(os.path.join(OUT, "pin_leakage.csv"), index=False)
vec_df.to_csv(os.path.join(OUT, "vector_info.csv"), index=False)

print(f"dice: {n}  wafers: {df.wafer_id.nunique()}  lots: {df.lot_id.nunique()}")
print(df["defect_type"].value_counts().to_string())
print(f"room IDDQ fails: {(df.room_iddq_pass == 0).sum()}  hot IDDQ fails: {(df.hot_iddq_pass == 0).sum()}  "
      f"pin fails: {(df.pin_leak_pass == 0).sum()}")
print(f"transient waveforms: {len(tr_df)}  pin rows: {len(pin_df)}")
