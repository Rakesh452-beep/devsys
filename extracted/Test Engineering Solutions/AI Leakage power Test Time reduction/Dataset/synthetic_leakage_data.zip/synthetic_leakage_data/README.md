# Synthetic Leakage Test Dataset

A reproducible, physics-inspired synthetic dataset for prototyping **leakage test time reduction** methods on ATE: early-termination prediction, IDDQ vector reduction, hot-from-room prediction, adaptive test, wafer spatial screening and group pin-leakage testing. It accompanies the PDF *AI-Optimized Leakage Test Time Reduction*.

All data is synthetic. No real product, fab or tester data is used. Every die has **ground truth** (true Vth shift, defect type, true settled current), so you can measure escapes and overkill exactly — something real production data cannot give you.

## Contents

| Path | What it is |
|---|---|
| `generate_synthetic_leakage_data.py` | Seeded generator (default seed 42). Re-run to regenerate or change size/parameters. |
| `demo_analysis.py` | Runs six demo analyses and writes `results/results.md` and two figures. |
| `data/die_data.csv` | 11,310 dice × 63 columns (6 lots × 5 wafers). |
| `data/settling_transients.csv` | 4,500 supply-current settling waveforms (1,500 dice × 3 vectors), 0–8 ms at 0.1 ms. |
| `data/pin_leakage.csv` | 361,920 rows: 32 pins per die. |
| `data/vector_info.csv` | True per-vector defect activation probability and background scale. |
| `results/results.md` | Demo results (see summary below). |
| `results/*.png` | Early-termination error distribution; recall vs. number of IDDQ vectors. |

## Quick start

```bash
pip install numpy pandas scikit-learn matplotlib tabulate
python generate_synthetic_leakage_data.py          # optional: --seed 7 --lots 10 --radius 14
python demo_analysis.py
```

Suggested split: **LOT01–LOT03 for training, LOT04–LOT06 for testing** (used by the demo), so results reflect unseen lots.

## How the data is generated

| Element | Model |
|---|---|
| Process variation | Threshold-voltage shift per die = lot offset (σ 8 mV) + wafer offset (σ 4 mV) + radial bowl + linear tilt + random die component (σ 5 mV) |
| Background IDDQ (25 °C) | 8 µA × exp(−ΔVth / (n·kT/q)), n = 1.5, × small log-normal noise |
| Vector dependence | Fixed per-vector scale (σ 5%) × per-die state noise (σ 2%) |
| Hot IDDQ (125 °C) | Room background × ratio ≈ 25 × exp(4·ΔVth[V]) with 5% noise |
| Bridge defects (1.2%) | Extra current (log-normal, median 15 µA) on vectors that activate the defect; each vector has its own activation probability (3–80%) |
| Temperature-activated defects (0.3%) | Only 10% of defect current at room; 15–40× larger at hot |
| ESD-damaged pin (0.5%) | One pin with extra leakage (log-normal, median 250 nA) |
| Measurement noise | 0.3 µA at room, 1.5 µA at hot |
| Settling waveform | I(t) = I_final + A₁e^(−t/τ₁) + A₂e^(−t/τ₂) + noise. A₁ ≈ 120 µA, τ₁ = 0.7–1.0 ms by site; slow tail A₂ ≈ 10 µA, τ₂ ≈ 2.5 ms; noise 0.4 µA |
| Limits | Room IDDQ 50 µA, hot IDDQ 1,500 µA, pin leakage 100 nA |

## Data dictionary

### `die_data.csv`

| Column | Unit | Description |
|---|---|---|
| `die_id` | – | Unique die ID |
| `lot_id`, `wafer_id` | – | Lot and wafer |
| `die_x`, `die_y` | die units | Position on wafer (centre = 0,0) |
| `r_norm` | – | Normalised radius (0 centre, 1 edge) |
| `dvth_true_mV` | mV | **Ground truth** Vth shift (not observable on a real tester) |
| `pcm_vth_V` | V | Wafer-level process-control-monitor Vth (one value per wafer) |
| `site` | – | Tester site 0–3 |
| `rosc_MHz`, `rosc_hvt_MHz` | MHz | Ring-oscillator frequencies (standard and high-Vt) |
| `defect_type` | – | **Ground truth**: `none`, `bridge`, `temp_activated`, `pin_esd` |
| `is_defective` | 0/1 | **Ground truth** defect flag |
| `iddq_room_v01_uA` … `v20` | µA | Measured room-temperature IDDQ per vector |
| `iddq_hot_v01_uA` … `v20` | µA | Measured 125 °C IDDQ per vector |
| `isb_sleep_uA`, `isb_retention_uA`, `isb_off_uA` | µA | Standby currents in three power modes (room) |
| `room_iddq_max_uA`, `hot_iddq_max_uA` | µA | Maximum over the 20 vectors |
| `room_iddq_pass`, `hot_iddq_pass` | 0/1 | Pass vs. absolute limit (50 µA / 1,500 µA) |
| `pin_leak_max_nA` | nA | Worst pin leakage |
| `pin_leak_pass` | 0/1 | Pass vs. 100 nA per-pin limit |
| `bad_pin_true` | – | **Ground truth** index of the damaged pin (−1 if none) |

### `settling_transients.csv`

| Column | Unit | Description |
|---|---|---|
| `die_id`, `site`, `vector` | – | Die, tester site, IDDQ vector (1, 7 or 14) |
| `i_final_true_uA` | µA | **Ground truth** settled current (what an infinitely long wait would read, without noise) |
| `tau1_ms`, `tau2_ms` | ms | **Ground truth** fast and slow time constants |
| `t0.0ms` … `t8.0ms` | µA | Sampled supply current every 0.1 ms after the vector is applied |

### `pin_leakage.csv`

| Column | Unit | Description |
|---|---|---|
| `die_id` | – | Die |
| `pin` | – | Pin index 0–31 |
| `leak_nA` | nA | Measured leakage magnitude |

### `vector_info.csv`

| Column | Description |
|---|---|
| `vector` | Vector number 1–20 |
| `defect_activation_prob_true` | **Ground truth** probability that a bridge defect is activated by this vector |
| `background_scale_true` | **Ground truth** vector-dependent background multiplier |

## Demo results summary (seed 42, test lots)

- **Early termination:** an exponential fit to 0.4–2 ms samples has zero false passes at every limit tested. It decides 77% of vectors early at a tight 15 µA limit and 100% at 50 µA. A black-box gradient-boosted model has lower average error but 14 false passes at 15 µA, because it regresses to the mean on high-current parts. Judge these models by tail behaviour, not MAE.
- **Vector reduction:** the absolute 50 µA limit catches only 14% of bridge defects. A noise-normalised delta-IDDQ screen catches 100% with all 20 vectors and ≥95% of that with 8 greedily chosen vectors, at ~0.2–0.3% overkill on unseen lots.
- **Hot prediction:** hot leakage is predicted from room data with R² = 0.94. But a room screen catches only 77% of temperature-activated defects versus 97% at hot, so skipping hot would raise escapes.
- **Wafer NNR:** removing spatial trends tightens the leakage distribution by 42%.
- **Group pin testing:** groups of 8 cut pin measurements by 87% with no missed fails.
- **Illustrative time:** 202 ms → 24–35 ms per part for room leakage tests (83–88% less), using the stated timing assumptions.

## Limitations

- Physics is first-order. Real transients can be multi-rail, non-exponential, and vary with tester hardware and load-board revisions.
- Defect models are simplified; real defect populations, activation patterns and temperature behaviour must come from your failure-analysis data.
- Rates (1.2% bridges, etc.) are inflated relative to mature production so that statistics are meaningful with ~11k dice.
- Use this dataset to develop and debug methods and pipelines, then re-validate on real characterization and production data.
