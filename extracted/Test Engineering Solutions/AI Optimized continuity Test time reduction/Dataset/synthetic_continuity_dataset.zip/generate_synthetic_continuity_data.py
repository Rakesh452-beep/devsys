"""
Synthetic continuity (open/short) test dataset generator
=========================================================
Companion to the white paper "AI-Optimized Continuity Test Time Reduction".

Simulates wafer-sort continuity testing of a 512-pin device on a dual-site
probe card, with physically motivated behaviour:
  * ESD-diode forward voltage with wafer gradient, die, pin and noise terms
  * probe-needle contact resistance that degrades with touchdowns since clean
  * heavy-tailed per-pin contact risk (edge/corner pins worse), per-site bias
  * device defects: opens, pin-to-pin / pin-to-ground shorts, ESD damage (outliers)
  * automatic retest of continuity failures; contact problems usually recover
  * probe-clean and needle-service maintenance events
  * settling-time characterization data (RC time constant per pin/site/temp)

All data is synthetic. Ground-truth labels (true_cause) are included so that
classification and outlier models can be trained and evaluated.

Usage:  python generate_synthetic_continuity_data.py [--seed 42] [--wafers 4] [--out ./data]
"""
import argparse, os
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=42)
ap.add_argument("--wafers", type=int, default=4)
ap.add_argument("--lots", type=int, default=2)
ap.add_argument("--out", default="./data")
args = ap.parse_args()
rng = np.random.default_rng(args.seed)
os.makedirs(args.out, exist_ok=True)

# ----------------------------------------------------------------- constants
N_PINS = 512
SITES = 2
I_FORCE = 100e-6                      # A (magnitude)
CLAMP = 1.8                           # V
LIM_VSS = (-0.90, -0.20)              # pass window, VSS-side (V)
LIM_VDD = (0.20, 0.90)                # pass window, VDD-side (V)
MARGIN_V = 0.06                       # within this of a limit -> MARGINAL flag (still passes)
CLEAN_EVERY = 120                     # touchdowns between probe cleans
SERVICE_EVERY = 4                     # needle service every N cleans... (per probe card)
DIE_GRID = 20                         # 20 x 20 grid, circular wafer mask
# time model (ms) - matches white paper baseline
T_RELAY, T_SETTLE, T_MEAS, T_SETUP = 0.30, 0.80, 0.10, 4.0

# ----------------------------------------------------------------- pin map
side = np.repeat(["N", "E", "S", "W"], N_PINS // 4)
idx_on_side = np.tile(np.arange(N_PINS // 4), 4)
pos = idx_on_side / (N_PINS // 4 - 1)                 # 0..1 along the side
corner_dist = np.minimum(pos, 1 - pos)                # 0 at corners
pin_type = rng.choice(["IO", "CLK", "ANALOG", "CTRL"], N_PINS, p=[0.78, 0.04, 0.08, 0.10])
ppmu_channel = np.arange(N_PINS)
ppmu_group = ppmu_channel // 64
trace_len = np.round(rng.uniform(4, 38, N_PINS) + 6 * (corner_dist < 0.05), 1)     # mm on probe card
pin_cap = np.round(np.where(pin_type == "ANALOG", rng.uniform(6, 14, N_PINS), rng.uniform(1.5, 6, N_PINS)), 2)  # pF
pin_vf_offset = rng.normal(0, 0.012, N_PINS)                                        # V, per-pin diode offset
pin_vf_offset[pin_type == "ANALOG"] += 0.04                                         # larger diodes -> smaller |Vf|
# contact risk: heavy tailed, corners and long needles worse
risk = (rng.pareto(1.8, N_PINS) + 0.05) * (1 + 3.0 * np.exp(-corner_dist / 0.04)) * (1 + trace_len / 40)
risk = risk / risk.mean()
pins = pd.DataFrame(dict(pin=[f"P{p:03d}" for p in range(N_PINS)], pin_index=np.arange(N_PINS), side=side,
                         position_on_side=np.round(pos, 4), corner_pin=(corner_dist < 0.05), pin_type=pin_type,
                         ppmu_channel=ppmu_channel, ppmu_group=ppmu_group, trace_len_mm=trace_len, pin_cap_pf=pin_cap))
pins.to_csv(f"{args.out}/pin_map.csv", index=False)

# neighbours for pin-to-pin shorts
neighbour = np.arange(N_PINS) + 1
neighbour[(np.arange(N_PINS) + 1) % (N_PINS // 4) == 0] -= 2

# ----------------------------------------------------------------- probe cards
cards = {"PC-A101": dict(site_bias=np.array([1.0, 1.6]), wear=1.0),
         "PC-A102": dict(site_bias=np.array([1.2, 0.9]), wear=1.4)}
# needle-level degradation multiplier per card/site/pin (some needles are bad)
needle_bad = {c: (rng.random((SITES, N_PINS)) < 0.006) * rng.uniform(3, 12, (SITES, N_PINS)) + 1 for c in cards}

# ----------------------------------------------------------------- wafers / dies
gx, gy = np.meshgrid(np.arange(DIE_GRID), np.arange(DIE_GRID))
c0 = (DIE_GRID - 1) / 2
rad = np.sqrt((gx - c0) ** 2 + (gy - c0) ** 2)
mask = rad <= DIE_GRID / 2 - 0.3
die_x, die_y, die_r = gx[mask], gy[mask], rad[mask] / (DIE_GRID / 2)
edge_die = die_r > 0.85

meas_rows, die_rows, maint_rows = [], [], []
cols = ["lot", "wafer", "die_x", "die_y", "edge_die", "probe_card", "site", "touchdown_id", "touchdowns_since_clean",
        "insertion", "temp_c", "pin_index", "polarity", "v_meas", "result", "marginal", "true_cause"]

td_global = 0
for lot_i in range(args.lots):
    lot = f"LOT{2610 + lot_i:04d}"
    card = list(cards)[lot_i % len(cards)]
    cinfo = cards[card]
    td_since_clean, cleans = 0, 0
    lot_vf_shift = rng.normal(0, 0.015)
    for w in range(1, args.wafers + 1):
        wafer = f"W{w:02d}"
        temp = 25.0 + rng.normal(0, 0.4)
        # wafer-level diode voltage gradient (radial + tilt)
        tilt = rng.normal(0, 0.01, 2)
        order = np.lexsort((die_x * (1 - 2 * (die_y % 2)), die_y))        # serpentine probing order
        dies = list(order)
        for k in range(0, len(dies), SITES):
            td_global += 1; td_since_clean += 1
            if td_since_clean > CLEAN_EVERY:
                cleans += 1; td_since_clean = 1
                ev = "NEEDLE_SERVICE" if cleans % SERVICE_EVERY == 0 else "PROBE_CLEAN"
                maint_rows.append(dict(lot=lot, wafer=wafer, probe_card=card, before_touchdown_id=td_global, event=ev))
                if ev == "NEEDLE_SERVICE":
                    needle_bad[card] = np.where(rng.random((SITES, N_PINS)) < 0.5, 1.0, needle_bad[card])
            for s, d in enumerate(dies[k:k + SITES]):
                dx, dy, r, edge = die_x[d], die_y[d], die_r[d], edge_die[d]
                vf_die = -0.62 + lot_vf_shift + 0.02 * r ** 2 + tilt[0] * (dx - c0) / c0 + tilt[1] * (dy - c0) / c0 \
                         + rng.normal(0, 0.008) + 0.0018 * (temp - 25)
                # ---- device defects (persist across retests)
                cause = np.array(["GOOD"] * N_PINS, dtype=object)
                u = rng.random()
                if u < 0.004 + 0.006 * edge:          # bond-pad/via open
                    cause[rng.integers(N_PINS)] = "DEVICE_OPEN"
                elif u < 0.007 + 0.009 * edge:        # metal short to neighbour or ground
                    p = rng.integers(N_PINS); cause[p] = "DEVICE_SHORT"
                    if rng.random() < 0.6: cause[neighbour[p]] = "DEVICE_SHORT"
                elif u < 0.011:                        # ESD damage -> leaky diode, parametric outlier
                    for p in rng.choice(N_PINS, rng.integers(1, 4), replace=False): cause[p] = "ESD_DAMAGE"
                esd_shift = rng.uniform(0.18, 0.32) * rng.choice([-1, 1], N_PINS)

                def contact_resistance():
                    """Contact resistance per pin (ohm) for one touchdown."""
                    wear = (1 + (td_since_clean / CLEAN_EVERY) ** 2 * 2.5 * cinfo["wear"])
                    lam = 0.000022 * risk * wear * cinfo["site_bias"][s] * needle_bad[card][s] * (1 + 1.5 * edge)
                    rc = rng.lognormal(np.log(3.0), 0.35, N_PINS)                 # healthy: ~3 ohm
                    bad = rng.random(N_PINS) < lam
                    marg = rng.random(N_PINS) < lam * 2.5
                    rc = np.where(marg, rng.uniform(600, 2600, N_PINS), rc)        # partial contact
                    rc = np.where(bad, rng.choice([1e9, 4000, 7000], N_PINS, p=[0.7, 0.15, 0.15]), rc)
                    return rc

                def measure(rc, polarity):
                    sgn = -1 if polarity == "VSS" else 1
                    v = sgn * (-(vf_die + pin_vf_offset)) + rng.normal(0, 0.004, N_PINS)
                    v = np.where(cause == "ESD_DAMAGE", v + sgn * esd_shift * 0.5, v)
                    v = v + sgn * I_FORCE * rc                                     # IR drop through contact
                    v = np.where(cause == "DEVICE_OPEN", sgn * CLAMP + rng.normal(0, 0.01, N_PINS), v)
                    v = np.where(cause == "DEVICE_SHORT", rng.normal(0, 0.012, N_PINS) + sgn * 0.01, v)
                    v = np.clip(v, -CLAMP, CLAMP) + rng.normal(0, 0.002, N_PINS) * (np.abs(v) >= CLAMP - 0.01)
                    lo, hi = LIM_VSS if polarity == "VSS" else LIM_VDD
                    res = np.where(np.abs(v) >= 1.4, "OPEN", np.where(np.abs(v) <= 0.10, "SHORT",
                                   np.where((v < lo) | (v > hi), "FAIL_LIMIT", "PASS")))
                    marginal = (res == "PASS") & ((v - lo < MARGIN_V) | (hi - v < MARGIN_V))
                    return np.round(v, 4), res, marginal

                rc = contact_resistance()
                contact_cause = np.where(rc > 3000, "CONTACT_OPEN", np.where(rc > 500, "CONTACT_MARGINAL", "GOOD"))
                true1 = np.where(cause != "GOOD", cause, contact_cause)
                results = {}
                for pol in ("VSS", "VDD"):
                    v, res, mg = measure(rc, pol)
                    results[pol] = (v, res, mg)
                    meas_rows.append(pd.DataFrame(dict(
                        lot=lot, wafer=wafer, die_x=dx, die_y=dy, edge_die=edge, probe_card=card, site=s,
                        touchdown_id=td_global, touchdowns_since_clean=td_since_clean, insertion=1, temp_c=round(temp, 2),
                        pin_index=np.arange(N_PINS), polarity=pol, v_meas=v, result=res, marginal=mg, true_cause=true1)))
                fail1 = any((results[p][1] != "PASS").any() for p in results)
                n_ins = 1
                final_fail = fail1
                if fail1:     # automatic retest (re-touch): contact usually recovers, device defects persist
                    n_ins = 2
                    rc2 = np.where(contact_cause != "GOOD",
                                   np.where(rng.random(N_PINS) < 0.72, rng.lognormal(np.log(3.0), 0.35, N_PINS), rc), rc)
                    cc2 = np.where(rc2 > 3000, "CONTACT_OPEN", np.where(rc2 > 500, "CONTACT_MARGINAL", "GOOD"))
                    true2 = np.where(cause != "GOOD", cause, cc2)
                    final_fail = False
                    for pol in ("VSS", "VDD"):
                        v, res, mg = measure(rc2, pol)
                        final_fail |= bool((res != "PASS").any())
                        meas_rows.append(pd.DataFrame(dict(
                            lot=lot, wafer=wafer, die_x=dx, die_y=dy, edge_die=edge, probe_card=card, site=s,
                            touchdown_id=td_global, touchdowns_since_clean=td_since_clean, insertion=2, temp_c=round(temp, 2),
                            pin_index=np.arange(N_PINS), polarity=pol, v_meas=v, result=res, marginal=mg, true_cause=true2)))
                dev_defect = sorted(set(cause[cause != "GOOD"]))
                t_cont = n_ins * (N_PINS * 2 * (T_RELAY + T_SETTLE + T_MEAS) + T_SETUP)
                die_rows.append(dict(lot=lot, wafer=wafer, die_x=dx, die_y=dy, edge_die=edge, probe_card=card, site=s,
                                     touchdown_id=td_global, touchdowns_since_clean=td_since_clean,
                                     first_pass_continuity="FAIL" if fail1 else "PASS",
                                     retested=n_ins == 2, final_continuity="FAIL" if final_fail else "PASS",
                                     hard_bin=7 if final_fail else 1, device_defect=";".join(dev_defect) or "NONE",
                                     continuity_time_ms=round(t_cont, 1)))

meas = pd.concat(meas_rows, ignore_index=True)
meas.insert(meas.columns.get_loc("pin_index"), "pin", "P" + meas["pin_index"].astype(str).str.zfill(3))
meas.to_csv(f"{args.out}/continuity_datalog.csv.gz", index=False, compression="gzip")
dies_df = pd.DataFrame(die_rows); dies_df.to_csv(f"{args.out}/die_summary.csv", index=False)
pd.DataFrame(maint_rows).to_csv(f"{args.out}/maintenance_events.csv", index=False)

# ----------------------------------------------------------------- settling characterization
rows = []
for card in cards:
    for s in range(SITES):
        for temp in (-40, 25, 125):
            for rep in range(3):
                tau_us = (8 + 1.2 * trace_len + 3.0 * pin_cap + 6 * (pin_type == "ANALOG") + 2.0 * s
                          + 0.03 * (temp - 25) + rng.normal(0, 2.5, N_PINS)) * (1.08 if card == "PC-A102" else 1.0)
                tau_us = np.clip(tau_us, 5, None)
                t_req = np.round(np.log(0.62 / 0.005) * tau_us, 1)       # time to settle within 5 mV
                rows.append(pd.DataFrame(dict(probe_card=card, site=s, temp_c=temp, repeat=rep + 1,
                                              pin=pins["pin"], pin_type=pin_type, ppmu_group=ppmu_group,
                                              trace_len_mm=trace_len, pin_cap_pf=pin_cap,
                                              tau_us=np.round(tau_us, 2), t_required_us=t_req)))
settle = pd.concat(rows, ignore_index=True)
settle.to_csv(f"{args.out}/settle_characterization.csv", index=False)

# example waveforms (a few pins) for visualisation
t = np.arange(0, 1000, 10.0)
wf = []
for p in [0, 64, 200, 333, 511]:
    tau = settle.query("probe_card=='PC-A101' and site==0 and temp_c==25 and repeat==1").iloc[p]["tau_us"]
    v = -0.62 * (1 - np.exp(-t / tau)) + rng.normal(0, 0.0015, t.size)
    wf.append(pd.DataFrame(dict(pin=f"P{p:03d}", t_us=t, v=np.round(v, 4))))
pd.concat(wf).to_csv(f"{args.out}/settle_waveforms_sample.csv", index=False)

# ----------------------------------------------------------------- summary
print("rows datalog:", len(meas), " dies:", len(dies_df), " maint events:", len(maint_rows), " settle rows:", len(settle))
print(dies_df[["first_pass_continuity", "final_continuity"]].apply(lambda c: (c == "FAIL").mean()).round(4).to_dict())
print("retest rate:", round(dies_df.retested.mean(), 4))
print(meas.query("insertion==1")["true_cause"].value_counts().to_dict())
print(pd.crosstab(meas.query("insertion==1").true_cause, meas.query("insertion==1").result))
