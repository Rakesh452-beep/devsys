# Synthetic Continuity Test Dataset

This is a synthetic companion dataset for the white paper *AI-Optimized Continuity Test Time Reduction*. It simulates wafer-sort open/short testing of a **512-pin device** on a **dual-site probe card**.

All values are generated. No real device, tester or fab data is included. Regenerate it, or change its size, with `generate_synthetic_continuity_data.py` (`--seed`, `--lots`, `--wafers`).

## Scope

| Item | Value |
|---|---|
| Lots / wafers | 2 lots × 4 wafers (LOT2610 on probe card PC-A101, LOT2611 on PC-A102) |
| Dies | 2,400 (300 per wafer, 20×20 grid with a circular mask) |
| Pins | 512 signal pins, both polarities (VSS-side and VDD-side diode) |
| Datalog rows | ~2.58 million (first insertion plus automatic retests) |
| First-pass continuity fail | ~4.9 % of dies |
| Final continuity fail (after retest) | ~1.7 % of dies |
| Probe clean | every 120 touchdowns; needle service every 4th clean |

## Files

### `continuity_datalog.csv.gz` — per-pin measurements (main table)

| Column | Description |
|---|---|
| lot, wafer, die_x, die_y | Die identity |
| edge_die | True if the die is in the outer 15 % of the wafer radius |
| probe_card, site | Probe card serial and site (0 or 1) |
| touchdown_id | Global touchdown counter |
| touchdowns_since_clean | Touchdowns since the last probe clean (drives contact wear) |
| insertion | 1 = first test, 2 = automatic retest |
| temp_c | Chuck temperature |
| pin, pin_index | Pin name and index (join to `pin_map.csv`) |
| polarity | VSS (force −100 µA) or VDD (force +100 µA) |
| v_meas | Measured voltage (V). Good pins read ≈ −0.62 V (VSS) / +0.62 V (VDD) |
| result | PASS, OPEN (\|V\| ≥ 1.4 V), SHORT (\|V\| ≤ 0.10 V), FAIL_LIMIT (outside the window but not open or short) |
| marginal | Passed, but within 60 mV of a limit |
| true_cause | **Ground-truth label**: GOOD, CONTACT_OPEN, CONTACT_MARGINAL, DEVICE_OPEN, DEVICE_SHORT, ESD_DAMAGE |

Limits: VSS −0.90 to −0.20 V, VDD +0.20 to +0.90 V, clamp ±1.8 V.

### `die_summary.csv` — one row per die

| Column | Description |
|---|---|
| first_pass_continuity | Continuity result on the first touchdown (PASS/FAIL) |
| retested | Whether the die was retested |
| final_continuity | Result after retest; hard_bin 7 = continuity fail, 1 = pass |
| device_defect | Injected device defect(s), or NONE |
| continuity_time_ms | Baseline serial-PMU continuity time, including the retest |

### `pin_map.csv` — hardware and pin attributes

Columns: pin, side (N/E/S/W), position_on_side, corner_pin, pin_type (IO/CLK/ANALOG/CTRL), ppmu_channel, ppmu_group (64 pins per group), trace_len_mm (probe card), pin_cap_pf.

### `maintenance_events.csv`

Probe-clean and needle-service events, with the touchdown before which each occurred.

### `settle_characterization.csv` — settling-time training data

512 pins × 2 probe cards × 2 sites × 3 temperatures (−40 / 25 / 125 °C) × 3 repeats.

- `tau_us` is the RC time constant.
- `t_required_us` is the time for the reading to settle within 5 mV of its final value.
- Both depend on trace_len_mm, pin_cap_pf, pin_type, site and temperature.

### `settle_waveforms_sample.csv`

Example settling waveforms (voltage vs. time) for 5 pins.

## Built-in behaviour (what models can learn)

- **Contact wear:** contact failure rate roughly doubles as `touchdowns_since_clean` approaches 120.
- **Pin risk:** corner pins fail about 2× more often. Per-pin risk is heavy-tailed, and a few individual needles are bad until the next needle service.
- **Edge dies:** about 2.5× higher contact failure rate and more device defects.
- **Site and card:** each probe card has a different site bias and wear rate.
- **Retest recovery:** about 70 % of contact problems clear on re-touch. Device opens and shorts always persist.
- **Partial contacts:** a 600–2,600 Ω contact resistance adds an IR drop. These readings mostly still pass but drift toward the limit, giving early warning.
- **ESD damage:** shifts the diode voltage by roughly 0.09–0.16 V but **stays inside the limits**. It can only be found by outlier detection (PAT).
- **Diode voltage variation:** varies with lot, a radial plus tilted wafer gradient, die, pin offset (ANALOG pins differ), temperature and noise.

## Suggested exercises (map to paper sections)

1. **§5.1 Settling time:** train on `settle_characterization.csv`, add a guard band, and build the per-`ppmu_group` wait table. Compare it with the fixed 800 µs wait.
2. **§5.2 Pin risk ordering:** rank pins by failure probability using pin_map, edge_die, site and touchdowns_since_clean. Measure the expected number of pins tested before the first fail.
3. **§5.4 Contact vs device:** classify first-insertion failures as CONTACT_* or DEVICE_* using spatial, site, voltage and wear features. Evaluate against the insertion-2 outcome.
4. **§5.5 Outliers:** detect the ESD_DAMAGE pins among the PASS results.
5. **§5.3 Adaptive VDD skip:** estimate how many defects would escape if the VDD polarity were skipped whenever VSS is clean.
